# -*- coding: utf-8 -*-
# Copyright (C) 2016 Harma Consulting, Inc.

import res_config
import website
